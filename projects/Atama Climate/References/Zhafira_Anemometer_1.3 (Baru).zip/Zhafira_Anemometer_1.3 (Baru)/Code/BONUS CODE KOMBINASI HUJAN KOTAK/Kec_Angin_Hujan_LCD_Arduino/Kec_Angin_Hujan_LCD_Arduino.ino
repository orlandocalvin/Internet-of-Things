//Curah hujan adalah jumlah air yang jatuh di permukaan tanah selama periode tertentu yang diukur dengan satuan tinggi milimeter (mm) di atas permukaan horizontal.
//Curah hujan 1 mm adalah jumlah air hujan yang jatuh di permukaan per satuan luas (m2) dengan volume sebanyak 1 liter tanpa ada yang menguap, meresap atau mengalir.
// Lebih lengkap silahkan dipelajari lebih lanjut disini https://www.climate4life.info/2015/12/hujan-1-milimeter-yang-jatuh-di-jakarta.html

//Perhitungan rumus
//Tinggi curah hujan (cm) = volume yang dikumpulkan (mL) / area pengumpulan (cm2)
//Luas kolektor (Corong) 5,4cm x 3,6cm = 19,44 cm2
//Koleksi per ujung tip kami dapat dengan cara menuangkan 100ml air ke kolektor kemudian menghitung berapa kali air terbuang dari tip,
//Dalam perhitungan yang kami lakukan air terbuang sebanyak 70 kali. 100ml / 70= 1.42mL per tip.
//Jadi 1 tip bernilai 1.42 / 19,44 = 0,07cm atau 0.70 mm curah hujan.

// PENTING
// Nilai kalibrasi yang kami lakukan berlaku untuk semua sensor curah hujan dan sensor Kecepatan angin yang kami jual tentu Anda dapat melakukan kalibrasi ulang sendiri jika dibutuhkan.

#include <Wire.h>
#include "RTClib.h"
#include <LiquidCrystal_I2C.h>

// Set alamat I2C LCD 0x27 / 0x3F
LiquidCrystal_I2C lcd(0x27, 20, 4);

RTC_DS3231 rtc;
DateTime now;
// Inisialisasi struktur waktu

String jam, menit, detik;
//Pin interrupt https://www.arduino.cc/reference/en/language/functions/external-interrupts/attachinterrupt/

// Untuk Kecepatan Angin Gunakan pin D2 pada Arduino
//================================================
volatile byte rpmcount; // hitung signals
volatile unsigned long last_micros;
unsigned long timeold;
unsigned long timemeasure = 10.00; // detik
int timetoSleep = 1;               // menit
unsigned long sleepTime = 15;      // menit
unsigned long timeNow;
int countThing = 0;
int GPIO_pulse = 2;                // Arduino = D2
float rpm, rotasi_per_detik;       // frekuensi
float kecepatan_kilometer_per_jam; // kilometer/jam
float kecepatan_meter_per_detik;   //meter/detik
//================================================

// Untuk Curah Hujan Gunakan pin D3 pada Arduino
//================================================
const int pin_interrupt = 3; // Arduino = D3
long int jumlah_tip = 0;
long int temp_jumlah_tip = 0;
float curah_hujan = 0.00;
float curah_hujan_per_menit = 0.00;
float curah_hujan_per_jam = 0.00;
float curah_hujan_per_hari = 0.00;
float curah_hujan_hari_ini = 0.00;
float temp_curah_hujan_per_menit = 0.00;
float temp_curah_hujan_per_jam = 0.00;
float temp_curah_hujan_per_hari = 0.00;
float milimeter_per_tip = 0.70;
String cuaca = "Berawan";
volatile boolean flag = false;
//================================================

void hitung_curah_hujan()
{
  flag = true;
}

/********************************************************************************
* // Fungsi ini dipanggil setiap kali magnet/interrupt terdeteksi oleh MCU
*********************************************************************************/
// Fungsi void rpm_anemometer() untuk menghitung putaran per menit (RPM)
void rpm_anemometer()
{
  // Cek apakah waktu sejak deteksi terakhir sudah lebih dari atau sama dengan 5000 mikrodetik (5 milidetik)
  if (long(micros() - last_micros) >= 5000)
  {
    // Jika ya, maka tambahkan satu ke penghitung rpm (rpmcount)
    rpmcount++;
    // Perbarui waktu terakhir ketika magnet terdeteksi dengan waktu saat ini
    last_micros = micros();
  }
  // Catatan: Kode untuk mencetak ke serial dihilangkan, biasanya digunakan untuk debugging
  // Serial.println("***** magnet terdeteksi *****");
}

void setup()
{
  Serial.begin(9600);

  // Inisialisasi LCD
  lcd.begin();

  // Menyalakan lampu latar lCD
  lcd.backlight();

  //Clear LCD
  lcd.clear();

  //====================== SETUP Curah Hujan ================================================
  pinMode(pin_interrupt, INPUT);
  attachInterrupt(digitalPinToInterrupt(pin_interrupt), hitung_curah_hujan, FALLING); // Akan menghitung tip jika pin berlogika dari HIGH ke LOW
  //====================== END SETUP Curah Hujan ================================================

  //====================== SETUP Angin ================================================
  pinMode(GPIO_pulse, INPUT_PULLUP);
  digitalWrite(GPIO_pulse, LOW);

  detachInterrupt(digitalPinToInterrupt(GPIO_pulse));                         // memulai Interrupt pada nol
  attachInterrupt(digitalPinToInterrupt(GPIO_pulse), rpm_anemometer, RISING); //Inisialisasi pin interupt
  rpmcount = 0;
  rpm = 0;
  timeold = 0;
  timeNow = 0;
  //====================== SETUP Angin ================================================

  // Inisialisasi RTC
  if (!rtc.begin())
  {
    Serial.println("Couldn't find RTC");
    while (1)
      ;
  }
  //=======Hanya dibuka komen nya jika akan kalibrasi waktu saja (hanya sekali) setelah itu harus di tutup komennya kembali supaya tidak set waktu terus menerus=======
  //rtc.adjust(DateTime(F(__DATE__), F(__TIME__))); // Set waktu langsung dari waktu PC
  //rtc.adjust(DateTime(2021, 12, 2, 8, 57, 0)); // Set Tahun, bulan, tanggal, jam, menit, detik secara manual
  // Cukup dibuka salah satu dari 2 baris diatas, pilih set waktu secara manual atau dari PC
  //===================================================================================================================================================================
  bacaRTC();
  printSerial_angin();
  printSerial_curah_hujan();
  // lcd.setCursor(0, 2);
  // lcd.print("/mnt=");
  // lcd.print(curah_hujan_per_menit, 1);
  // lcd.print(",/jam=");
  // lcd.print(curah_hujan_per_jam, 1);
  // lcd.print(" ");
  lcd.setCursor(0, 2);
  lcd.print("/hari=");
  lcd.print(curah_hujan_per_hari, 1);
  lcd.print(" mm ");
  printSerial_angin(); // print serial 10 detik sekali
  lcd.setCursor(0, 3);
  lcd.print("Angin=");
  lcd.print(kecepatan_meter_per_detik, 1);
  lcd.print(" m/s  ");
}

void loop()
{
  //Measure RPM
  if ((millis() - timeold) >= timemeasure * 1000)
  {
    detachInterrupt(digitalPinToInterrupt(GPIO_pulse));      // Menonaktifkan interrupt saat menghitung
    rotasi_per_detik = float(rpmcount) / float(timemeasure); // rotasi per detik
    //kecepatan_meter_per_detik = rotasi_per_detik; // rotasi/detik sebelum dikalibrasi untuk dijadikan meter per detik
    kecepatan_meter_per_detik = ((-0.0181 * (rotasi_per_detik * rotasi_per_detik)) + (1.3859 * rotasi_per_detik) + 1.4055); // meter/detik sesudah dikalibrasi dan sudah dijadikan meter per detik
    if (kecepatan_meter_per_detik <= 1.5)
    { // Minimum pembacaan sensor kecepatan angin adalah 1.5 meter/detik
      kecepatan_meter_per_detik = 0.0;
    }
    kecepatan_kilometer_per_jam = kecepatan_meter_per_detik * 3.6; // kilometer/jam
    printSerial_angin();                                           // print serial 10 detik sekali
    lcd.setCursor(0, 3);
    lcd.print("Angin=");
    lcd.print(kecepatan_meter_per_detik, 1); // Minimal kecepatan angin yang dapat dibaca sensor adalah 4 m/s dan maksimum 55 m/s.
    lcd.print(" m/s  ");
    timeold = millis();
    rpmcount = 0;
    attachInterrupt(digitalPinToInterrupt(GPIO_pulse), rpm_anemometer, RISING); // aktifkan interrupt
  }

  if (flag == true)
  {
    curah_hujan += milimeter_per_tip; // Akan bertambah nilainya saat tip penuh
    jumlah_tip++;
    delay(500);
    flag = false; // reset flag
  }
  bacaRTC();
  curah_hujan_hari_ini = jumlah_tip * milimeter_per_tip;
  lcd.setCursor(0, 1);
  lcd.print(konversi_jam(jam) + ":" + konversi_jam(menit));
  lcd.print("->");
  lcd.print(jumlah_tip);
  lcd.print("x,");
  lcd.print(curah_hujan_hari_ini, 1);
  lcd.print(" ");
  temp_curah_hujan_per_menit = curah_hujan;

  //Probabilistik Curah Hujan https://www.bmkg.go.id/cuaca/probabilistik-curah-hujan.bmkg
  if (curah_hujan_hari_ini <= 0.00 && curah_hujan_hari_ini <= 0.50)
  {
    cuaca = "Berawan           ";
  }
  if (curah_hujan_hari_ini > 0.50 && curah_hujan_hari_ini <= 20.00)
  {
    cuaca = "Hujan Ringan      ";
  }
  if (curah_hujan_hari_ini > 20.00 && curah_hujan_hari_ini <= 50.00)
  {
    cuaca = "Hujan Sedang      ";
  }
  if (curah_hujan_hari_ini > 50.00 && curah_hujan_hari_ini <= 100.00)
  {
    cuaca = "Hujan Lebat       ";
  }
  if (curah_hujan_hari_ini > 100.00 && curah_hujan_hari_ini <= 150.00)
  {
    cuaca = "Hujan Sangat Lebat";
  }
  if (curah_hujan_hari_ini > 150.00)
  {
    cuaca = "Hujan ekstrem     ";
  }
  lcd.setCursor(0, 0);
  lcd.print(cuaca);      // Print cuaca hari ini (Ini bukan ramalan cuaca tapi membaca cuaca yang sudah terjadi/ sedang terjadi hari ini)
  if (detik.equals("0")) // Hanya print pada detik 0
  {
    curah_hujan_per_menit = temp_curah_hujan_per_menit; // Curah hujan per menit dihitung ketika detik 0
    temp_curah_hujan_per_jam += curah_hujan_per_menit;  // Curah hujan per jam dihitung dari penjumlahan curah hujan per menit namun disimpan dulu dalam variabel temp
    if (menit.equals("0"))
    {
      curah_hujan_per_jam = temp_curah_hujan_per_jam;   // Curah hujan per jam baru dihitung ketika menit 0
      temp_curah_hujan_per_hari += curah_hujan_per_jam; //// Curah hujan per hari dihitung dari penjumlahan curah hujan per jam namun disimpan dulu dalam variabel temp
      temp_curah_hujan_per_jam = 0.00;                  // Reset temp curah hujan per jam
    }
    if (menit.equals("0") && jam.equals("0"))
    {
      curah_hujan_per_hari = temp_curah_hujan_per_hari; // Curah hujan per jam baru dihitung ketika menit 0 dan jam 0 (Tengah malam)
      temp_curah_hujan_per_hari = 0.00;                 // Reset temp curah hujan per hari
      curah_hujan_hari_ini = 0.00;                      // Reset curah hujan hari ini
      jumlah_tip = 0;                                   // Jumlah tip di reset setap 24 jam sekali (Tengah malam)
    }
    lcd.setCursor(0, 2);
    lcd.print("/hari=");
    lcd.print(curah_hujan_per_hari, 1);
    lcd.print(" mm ");
    temp_curah_hujan_per_menit = 0.00;
    curah_hujan = 0.00;
    delay(1000);
  }
  if ((jumlah_tip != temp_jumlah_tip) || (detik.equals("0"))) // Print serial setiap 1 menit atau ketika jumlah_tip berubah
  {
    printSerial_curah_hujan();
  }
  temp_jumlah_tip = jumlah_tip;
}

String konversi_jam(String angka) // Fungsi untuk supaya jika angka satuan ditambah 0 di depannya, Misalkan jam 1 maka jadi 01 pada LCD
{
  if (angka.length() == 1)
  {
    angka = "0" + angka;
  }
  else
  {
    angka = angka;
  }
  return angka;
}

void bacaRTC()
{
  now = rtc.now(); // Ambil data waktu dari DS3231
  jam = String(now.hour(), DEC);
  menit = String(now.minute(), DEC);
  detik = String(now.second(), DEC);
}

void printSerial_angin()
{
  Serial.print("RPS=");
  Serial.println(rotasi_per_detik);
  Serial.print("RPM=");
  Serial.println(rpm);
  Serial.print("Kecepatan=");
  Serial.print(kecepatan_meter_per_detik); // Minimal kecepatan angin yang dapat dibaca sensor adalah 1.5 meter/detik dan maksimum 30 meter/detik.
  Serial.print(" m/s, ");
  Serial.print(kecepatan_kilometer_per_jam);
  Serial.println(" Km/jam");
}

void printSerial_curah_hujan()
{
  Serial.println("Waktu=" + konversi_jam(jam) + ":" + konversi_jam(menit));
  Serial.print("Cuaca=");
  Serial.println(cuaca); // Print cuaca hari ini (Ini bukan ramalan cuaca tapi membaca cuaca yang sudah terjadi/ sedang terjadi hari ini)
  Serial.print("Jumlah tip=");
  Serial.print(jumlah_tip);
  Serial.println(" kali ");
  Serial.print("Curah hujan hari ini=");
  Serial.print(curah_hujan_hari_ini, 1);
  Serial.println(" mm ");
  Serial.print("Curah hujan per menit=");
  Serial.print(curah_hujan_per_menit, 1);
  Serial.println(" mm ");
  Serial.print("Curah hujan per jam=");
  Serial.print(curah_hujan_per_jam, 1);
  Serial.println(" mm ");
  Serial.print("Curah hujan per hari=");
  Serial.print(curah_hujan_per_hari, 1);
  Serial.println(" mm ");
}
